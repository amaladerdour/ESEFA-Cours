/* Type bool�en */
typedef enum
	{
		false, //0
		true //1
	}Bool;

/*------------------------------------------*/

/* D�finition d'un Joueur */
typedef struct Player
	{
		char nom[25];
		char prenom[25];
		int numero;
	}Player;

/*------------------------------------------*/

/* D�finition d'une Pile */
typedef struct StackElement
	{
		Player P;
		struct StackElement *next;
	}StackElement, *Stack;

/*------------------------------------------*/

/*-------- Prototypes des fonctions--------------*/
Stack new_stack(void);
Bool is_empty_stack(Stack st);
void print_stack(Stack st);
Stack push_stack(Stack st, Player joueur);
Stack pop_stack(Stack st);
Player top_stack(Stack st);
int stack_length(Stack st);
Stack clear_stack(Stack st);


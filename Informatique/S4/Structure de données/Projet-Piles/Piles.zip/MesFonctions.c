#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "MesFonctions.h"

/************Cr�er une pile************* */
Stack new_stack(void)
    {
        return NULL;// Retourne une Pile vide
    }

/*-----------------------------------------------------------------*/

/*** V�rifie si une Pile est vide, retournesi la Pile est vide, faux sinon*/
Bool is_empty_stack(Stack st)
    {
        if(st == NULL)
        return true;
        return false;
    }

/*-----------------------------------------------------------------*/

/*** Empile un joueur dans la Pile*/
Stack push_stack(Stack st, Player joueur)
    {
        StackElement *element;
        element = malloc(sizeof(*element));
        if(element == NULL)
            {
                fprintf(stderr, "Probleme allocation dynamique.\n");
                exit(EXIT_FAILURE);
            }
        strcpy(element->P.nom, joueur.nom);
        strcpy(element->P.prenom, joueur.prenom);
        element->P.numero = joueur.numero;
        element->next = st;
        return element;
    }

/*-------------------Supprimer la d�rnier element----------------------------------------------*/

/*** D�pile un joueur de la Pile*/
Stack pop_stack(Stack st)
    {
        StackElement *element;
        if(is_empty_stack(st))
        return new_stack();
        element = st->next;
        free(st);
        return element;
    }

/*-----------------------------------------------------------------*/

/*** Affiche une Pile*/
void print_stack(Stack st)
    {
        if(is_empty_stack(st))
            {
                return;
            }
        while(!is_empty_stack(st))
            {
                printf("[%s %s- numero %d]\n", st->P.nom, st->P.prenom,st->P.numero);
                st = st->next;
            }
    }

/*-----------------------------------------------------------------*/

/*** Retourne le joueur au sommet de la Pile*/
Player top_stack(Stack st)
    {
        if(is_empty_stack(st))
            {
                printf("Aucun sommet, la Pile est vide.\n");
                exit(EXIT_FAILURE);
            }
        return st->P;
    }

/*-----------------------------------------------------------------*/

/*** Retourne la hauteur (longueur) de la Pile*/
int stack_length(Stack st)
{
	int length = 0;
	while(!is_empty_stack(st))
        {
            length++;
            st = st->next;
        }
	return length;
}

/*-----------------------------------------------------------------*/

/*** Vide la Pile de ses �l�ments*/
Stack clear_stack(Stack st)
    {
        while(!is_empty_stack(st))
        st = pop_stack(st);
        return new_stack();
    }


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "MesFonctions.h"
int main(void)
{
    printf("********************GESTION DES EQUIPES SPORTIVES****************\n");
    Player* joueur=malloc(sizeof(Player));
    int choix;
    char nom[10];
    Stack sta= new_stack();//cree un pile
    print_stack(sta);
    printf("Nom de l'equipe:\n");
    scanf("%s", &nom);
    printf("Bienvenue '%s' , Pour : \n -Une equipe de FOOTBALL, entrer 12 joueurs.\n -Une equipe de VOLLEYBALL, entrer 7 joueur. \n -Une equipe de Tennis, entrer 2joueurs\n", nom);
    printf("------Effectuez un choix:------\n");

    printf("\t1- Ajouter un joueur \n");
    printf("\t2- Supprimer un joueur \n REMARQUE!!: Le dernier jouer integre dans l'equipe est le premier a virer!!  \n");
    printf("\t3- le nombre des joueurs dans mon equipe \n");
    printf("\t4- Supprimer tout les joueurs \n");
    printf("\t5- Afficher l'ensemble de mon equipe \n");
    printf("\t!!ATTENTION!!: Si vous souhaitez quitter, TAPEZ 0\n");
    do{
    printf("Saisissez votre choix:\t");
    scanf("%d",&choix);
    switch(choix)
    {
        case 1:{// ajouter un joueur
                 printf("Nom du joueur:\t");
                 scanf("%s",joueur->nom);
                 printf("Prenom du joueur:\t");
                 scanf("%s",joueur->prenom);
                 printf("Numero du joueur:\t");
                 scanf("%d",&joueur->numero);
                 sta =push_stack(sta,*joueur);
               };break;
        case 2:{//Supprimer la d�rnier element
                Player last =top_stack(sta);
                printf("\nDernier joueur est: %s %s -Numero: %d\n",last.nom,last.prenom,last.numero);
                sta = pop_stack(sta);
                printf("OUPS!! Le dernier joueur a etait bien vire. \n");
               };break;
        case 3:{// l'affichage de la langeur de la pile
                 printf("Votre equipe contient %d joueurs.\n",stack_length(sta));
               };break;
        case 4:{// Supprimer tout les elements de la pile
                 sta =clear_stack(sta);
                 //print_stack(sta);
               };break;
        case 5:{// l'affichage de la pile
                 printf("l'equipe se represente comme suit: :\n");
                 print_stack(sta);
               };break;
     }
     printf("\n");
     }while(choix !=0);

    return 0;
}

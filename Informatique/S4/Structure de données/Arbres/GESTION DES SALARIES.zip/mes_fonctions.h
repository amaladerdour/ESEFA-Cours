#ifndef __MES_FONCTIONS__H__
#define __MES_FONCTIONS__H__


/* Structure d'un element */
    typedef struct Employe
    {
        char nom[30];
        char prenom[30];
        int salaire;
        int annee_Entree;

    }Employe;

/* Structure d'un Arbre */
typedef struct Tree
{
	Employe info;
	struct Tree *tleft;
	struct Tree *tright;
    struct Tree *parent;
}Tree;


/* Prototypes des fonctions */
Tree *new_tree(Employe X);
void clean_tree(Tree *tr);
Tree *join_tree(Tree *left, Tree *right,Employe node);
void print_tree_prefix(Tree *tr);
Tree* ajouter(Tree *tr,Employe X);
int count_tree_nodes(Tree *tr);
int nbfeuille(Tree *tr);
int Rechercher(Tree *tr,Employe value);
int Calcul_2020(Tree *tr);
int is_empty_Tree(Tree* tr);

#endif

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "mes_fonctions.h"
int main()
{
    printf("********************GESTION D'UNE ENTREPRISE/SALARIES********************\n");
    Tree* arbre=malloc(sizeof(Tree));
    int choix;
    Employe* derct =malloc(sizeof(Employe));// directeur
    Employe* chef_I =malloc(sizeof(Employe));// chef de service d'informatique
    Employe* chef_C =malloc(sizeof(Employe));//chef de service de commerce
    Employe* OfficerI =malloc(sizeof(Employe));// 1er employ� dans service d'informatique
    Employe* OfficerI2 =malloc(sizeof(Employe));// 2�m� employ� dans service d'inforrmatique
    Employe* OfficerC =malloc(sizeof(Employe));// 1er employ� dans service de commerce
    Employe* OfficerC2 =malloc(sizeof(Employe));// 2�m� employ� dans service de commerce
    Employe* newD =malloc(sizeof(Employe));

    printf("Salut! Veuillez commencer par saisir les informations du directeur:");
    printf("\n\t - Nom et Prenom: ");
    scanf("%s %s",&derct->nom,&derct->prenom);
    printf("\t - Salaire : ");
    scanf("%d",&derct->salaire);
    printf("\t - Ann%ce d'entr%ce: ",130,130);
    scanf("%d",&derct->annee_Entree);

    arbre = new_tree(*derct);//cree un arbre

    //system("cls");
    printf("\nBienvenue '%s %s' tu peux maintenant g%crer votre entreprise.\n" , derct->nom,derct->prenom, 130);
    printf("REMARQUE: Cette entreprise contiendra DEUX chefs de services. A chaque service, il y aura deux employ%cs.\n",130);
     printf("\nSaisissez les informations du chef de service 'd'informatique':\n");
    printf("\t - Nom et Prenom: ");
    scanf("%s %s",&chef_I->nom,&chef_I->prenom);
    printf("\t - Salaire: ");
    scanf("%d",&chef_I->salaire);
    printf("\t - Ann%ce d'entr%ce: ",130,130);
    scanf("%d",&chef_I->annee_Entree);
    printf("Saisissez les informations du chef service de 'commerce':\n");
    printf("\t - Nom et Prenom: ");
    scanf("%s %s",&chef_C->nom,&chef_C->prenom);
    printf("\t - Salaire: ");
    scanf("%d",&chef_C->salaire);
    printf("\t - Ann%ce d'entr%ce: ",130,130);
    scanf("%d",&chef_C->annee_Entree);
    printf("\n**Service d'informatique:**\n __REMARQUE: Vous pouvez ajouter deux employ%cs a chaque service.__\n",130);
    printf("\nSaisissez les informations des deux employ%cs :\n",130);
                 printf("\t - Nom et Prenom: ");
                 scanf("%s %s",&OfficerI->nom,&OfficerI->prenom);
                 printf("\t - Salaire: ");
                 scanf("%d",&OfficerI->salaire);
                 printf("\t - Ann%ce d'entr%ce: ",130,130);
                 scanf("%d",&OfficerI->annee_Entree);
                 printf("--> Deuxieme employ%c:\n\t - Nom et Prenom: ", 130); //  2eme employ�
                 scanf("%s %s",&OfficerI2->nom,&OfficerI2->prenom);
                 printf("\t - Salaire: ");
                 scanf("%d",&OfficerI2->salaire);
                 printf("\t - Ann%ce d'entr%ce: ",130,130);
                 scanf("%d",&OfficerI2->annee_Entree);
    printf("\n**Service de commerce:**\n");
    printf("\nSaisissez les informations des deux employ%cs :\n",130);
                 printf("\t - Nom et Prenom: ");
                 scanf("%s %s",&OfficerC->nom,&OfficerC->prenom);
                 printf("\t - Salaire: ");
                 scanf("%d",&OfficerC->salaire);
                 printf("\t - Ann%ce d'entr%ce: ",130,130);
                 scanf("%d",&OfficerC->annee_Entree);
                 printf("--> Deuxieme employ%c:\n\t - Nom et Prenom: ",130); //  2eme employ�
                 scanf("%s %s",&OfficerC2->nom,&OfficerC2->prenom);
                 printf("\t - Salaire: ");
                 scanf("%d",&OfficerC2->salaire);
                 printf("\t - Ann%ce d'entr%ce: ",130,130);
                 scanf("%d",&OfficerC2->annee_Entree);

    arbre= join_tree(join_tree(new_tree(*OfficerI),new_tree(*OfficerI2),*chef_I),join_tree(new_tree(*OfficerC),new_tree(*OfficerC2),*chef_C),*derct);
    system("cls");
    printf("\n--------Effectuez un choix:--------\n");

    printf("\t1- Tapez 1 pour changer le directeur \n");
    printf("\t2- Tapez 2 pour Afficher l'ensemble des employes de l'entreprise\n");
    printf("\t3- Le nombre des employes de l'entreprise \n");
    printf("\t4- Le nombre total des personnes dans l'entreprise\n");
    printf("\t5- Chercher un employe dans l'entreprise \n");
    printf("\t6- Nombre des employes qui ont integre l'entreprise avant ou egal a l'an 2020 \n", 130 );
    printf("\t7- Supprimer tout les employes de l'entreprise\n");

    printf("\t!!ATTENTION!!: Si vous souhaitez quitter, TAPEZ 0\n");
    do{
    printf("\nSaisissez votre choix:\t");
    scanf("%d",&choix);
    switch(choix)
    {
        case 1:{
                 printf("\nSaisissez les informations du nouveau directeur:\n");
                 printf("\t - Nom et Prenom: ");
                 scanf("%s %s",newD->nom,&newD->prenom);
                 printf("\t - Salaire: ");
                 scanf("%d",&newD->salaire);
                 printf("\t - Ann%ce d'entr%ce: ",130,130);
                 scanf("%d",&newD->annee_Entree);
                 arbre=ajouter(arbre,*newD);
               };break;
        case 2:{
                 print_tree_prefix(arbre);
               };break;
        case 3:{
                printf("\n- Le nombre des employ%cs est: %d\n",130, nbfeuille(arbre));
               };break;
        case 4:{
                printf("\n- Le nombre total des personnes dans l'entreprise: %d",count_tree_nodes(arbre));
               };break;
        case 5:{
                 Employe* val=malloc(sizeof(Employe));
                 printf("\n Entrez les informations de l'employ%c cherch%c:\n",130, 130);
                 printf("\t Nom et Prenom: ");
                 scanf("%s %s",&val->nom,&val->prenom);
                 printf("\t salaire: ");
                 scanf("%d",&val->salaire);
                 printf("\t Ann%ce d'entr%ce: ",130,130);
                 scanf("%d",&val->annee_Entree);
                 if(Rechercher(arbre,*val))
                     printf("\t- OUI, Employ%c trouv%c",130,130);
                  else   printf("\t- OUPS!! Cet employ%c n'existe pas",130);
               };break;
        case 6:{
                 printf("- Le nombre des employes qui ont integrE l'entreprise avant ou egal a l'an de 2020 sont :%d\n",Calcul_2020(arbre));
               };break;
        case 7:{
                clean_tree(arbre);
                 printf("\n Entreprise vide");
                 free(arbre);
               };break;
     }
     printf("\n");
     }while(choix !=0);



    free(arbre);
    return 1;
}

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "mes_fonctions.h"
/**
* Cr��e un nouvel Arbre
* @param x La valeur de la racine
* @return Le nouvel arbre cr��
*/
Tree* new_tree(Employe X)
{
	Tree *tr = malloc(sizeof(*tr));
	if(tr == NULL)
	{
		fprintf(stderr, "Erreur allocation memoire.\n");
		exit(EXIT_FAILURE);
	}

	tr->info = X;
	tr->tleft = NULL;
	tr->tright = NULL;
	tr->parent = NULL;

	return tr;
}
/*-----------------------------------------------------------------------*/
/**
* Nettoie un arbre
* @param tr L'arbre � vider de ses valeurs
*/
void clean_tree(Tree *tr)
{
	if(tr == NULL)
		return;

	tr->tleft=NULL;
	tr->tright=NULL;
	tr->parent=NULL;
    free(&tr->info);
}
/*-----------------------------------------------------------------------*/
/**
* Joint deux arbres pour n'en former qu'un
* @param left L'arbre de gauche
* @param right L'arbre de droite
* @param node Le noeud qui lie les deux arbres
* @return Le nouvel arbre form�
*/
Tree *join_tree(Tree *left, Tree *right,Employe node)
{
	Tree *tr = new_tree(node);

	tr->tleft = left;
	tr->tright = right;

    if(left != NULL)
		left->parent = tr;
	if(right != NULL)
		right->parent = tr;
	return tr;
}
/*-----------------------------------------------------------------------*/
/**
* Affiche un arbre r�cursivement (parcours pr�fix�)
* @param tr L'arbre � parcourir
*/
void print_tree_prefix(Tree *tr)
{
	if(tr== NULL)
		{
            printf("\tRien a afficher, l'arbre est vide.\n");
            return;
        }
    if(tr->parent != NULL)
    	printf("(%s %s) -> (%s %s)\n",tr->parent->info.nom,tr->parent->info.prenom,tr->info.nom,tr->info.prenom);
    else
    	printf("(%s %s)\n", tr->info.nom, tr->info.prenom);
    if(tr->tleft != NULL)
    	print_tree_prefix(tr->tleft);

    if(tr->tright != NULL)
    	print_tree_prefix(tr->tright);
}

/*-----------------------------------------------------------------------*/
/**
****Teste si un arbre est vide
*/
int is_empty_Tree(Tree* tr)
{
	if(tr == NULL)
		return 1;

	return 0;
}
/*-----------------------------------------------------------------------*/

/**
*Ajoute un �l�ment � l'arbre
*/
Tree* ajouter(Tree *tr,Employe X)
{
        if(tr ==NULL)
            return new_tree(X);
        tr=join_tree(tr->tleft,tr->tright,X);
    return (tr);
}

/*-----------------------------------------------------------------------*/
/**
* Compte le nombre de noeuds d'un arbre(Taille)
* @param tr L'arbre dont il faut compter les noeuds
* @return Le nombre de noeuds de l'arbre binaire
*/
int count_tree_nodes(Tree *tr)
{
	if(tr == NULL)
		return 0;

	return (count_tree_nodes(tr->tleft) + count_tree_nodes(tr->tright) + 1);
}
/*-----------------------------------------------------------------------*/
/**
* Nombre de feuilles d�un arbre binaire
*/
int nbfeuille(Tree *tr)
{
    if(tr == NULL)
    return 0;

        if ((tr->tleft == NULL)&&(tr->tright == NULL))
        return 1;
        else
         return (nbfeuille(tr->tleft)+nbfeuille(tr->tright));
}
/*-----------------------------------------------------------------------*/
/**
* Recherche un element
*valeur est pr�sent dans l'arbre ou non
*/
int Rechercher(Tree *tr,Employe value)
{
       if(tr ==NULL)return 0;

        if ((tr->info.annee_Entree) == (value.annee_Entree)) return 1;
        if (value.salaire > tr->info.salaire)
                  Rechercher(tr->tleft,value);
             else Rechercher(tr->tright,value);

}
/*-----------------------------------------------------------------------*/
/**
* calculer les employ� qui sont entre avant 2020
*/
int Calcul_2020(Tree *tr)
{
    int n;
    if(tr ==NULL)
       n=0;
    else
    {
        if((tr->info.annee_Entree)<=2020)
        n=1+Calcul_2020(tr->tleft)+Calcul_2020(tr->tright);
        else
        n=Calcul_2020(tr->tleft)+Calcul_2020(tr->tright);
    }
    return n;
}

// structeur  des nombres complexes
typedef struct complexe {
   float Reel ;
   float Im ;
}Tcomplexe;

struct maillon
 {
    Tcomplexe valeur; //valeur
    struct maillon *suivant;
 };
 typedef struct maillon *Tmaillon;
struct liste {

   Tmaillon *pTete ;
   Tmaillon *pQueue ;

};
typedef struct liste TListe;
//************************ Les prototypes ****************************************
TListe *CreerListe();
Tcomplexe CreeComplexe(double x , double y);
Tmaillon CreerMaillon(Tcomplexe val );
int ListeVide(TListe*L);
int LongListe (TListe *L);
void afficher_liste(TListe *L);
int InsererTete(TListe *L,Tcomplexe val );
TListe InsererQueue (TListe *L,Tcomplexe val);
Tmaillon InsererMaillon(TListe *L, Tcomplexe elementAjouter);
void chercherComplexe(TListe *tete,Tcomplexe val);
void SupprTete(TListe *L);
double Module (Tcomplexe Z);
Tcomplexe Somme (Tcomplexe Z1, Tcomplexe Z2 );

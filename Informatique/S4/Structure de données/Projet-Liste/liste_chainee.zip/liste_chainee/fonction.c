#include<stdlib.h>
#include<stdio.h>
#include<conio.h>
#include <stdbool.h>
#include <math.h>
#include"fonction.h"

//************************ Les fonctions ****************************************

// *********************La creation d'une liste**************************
TListe *CreerListe()
{
    TListe *pL;
    pL= malloc(sizeof(TListe));
    pL->pTete = NULL;
    pL->pQueue = NULL;
    //printf("La liste est bien cree.");
  return pL;
}
// ********************cr�ation d'une Complexe (saisir un nombre complexe)

Tcomplexe CreeComplexe(double x , double y)
{

    Tcomplexe *Z;
  Z=malloc(sizeof(Tcomplexe));
  Z->Reel=x;
  Z->Im=y;
return *Z;

}
// *******************Cr�er Maillon********************************
Tmaillon CreerMaillon(Tcomplexe val )
{
    Tmaillon m;
    m = (Tmaillon)malloc(sizeof(Tmaillon));

    m -> valeur=val;         //=CreeComplexe(val.Reel,val.Im);
    m -> suivant =NULL;
    return m;
}
//********************* cr�ation d'une liste vide*********************
int ListeVide(TListe*L)
{
return (L->pTete==NULL);
}
// *********************long liste***********************************
int LongListe (TListe *L)
{
    int longueur =0;
    Tmaillon pL;  //=malloc(sizeof(Tmaillon));
    pL = L->pTete ;
    if(ListeVide(L)) return longueur;
    else
    {   while(pL != NULL)
        {
            longueur++;
            pL = pL->suivant;
        }
    }
    return longueur;
}

//*******************l'affichage de la liste**********************
void afficher_liste(TListe *L)// un pointeur vers la 1er maillon
{
    //Tcomplexe *val;
   //Tmaillon pt;
    //printf("\n affichage de la liste\n");
    if (ListeVide(L)){
        printf("Rien a afficher, la liste est vide\n");
        return ;
    }
        Tmaillon pt = L->pTete;
        while(pt != NULL)
         {
            Tcomplexe c = pt->valeur;
            printf("%.2f +i %.2f\n",c.Reel,c.Im);
            pt = pt->suivant;
         }
         printf("\n");
}
//*********************inserer tete******************************
int InsererTete(TListe *L,Tcomplexe val )
{
        Tmaillon tmp; //= malloc(sizeof(Tmaillon));
        tmp= CreerMaillon(val);
        if (tmp==NULL) return 0;
        tmp->suivant= L->pTete;
        L->pTete=tmp;
        return 1;
}
// ********************inserer maillon***************************
Tmaillon InsererMaillon(TListe *L, Tcomplexe elementAjouter)
{
    //cr�e un nouveux maillon
    Tmaillon pred;
    Tmaillon succ;
    Tmaillon nouveuM;
    int position;
    printf("Ou voulez-vous saisir ce nombre dans la liste?\nREMARQUE: La position suggeree doit etre comprise entre 1 et %d\n",LongListe(L));
    scanf("%d",&position);
    nouveuM = malloc(sizeof(Tmaillon));
    nouveuM= CreerMaillon(elementAjouter); //elementAjouter;
    //nouveuM->suivant = NULL;
    // Si la liste est vide
    //if(ListeVide(L)) return nouveuM;
    // Si la liste n'est pas vide

    if(InsererTete(L,elementAjouter)== NULL) printf("Veuillez saisir un nombre en tete (choix: 1)");

    else
     if(position <= LongListe(L) )//Insere Queue
       {
            int i=1;
            pred=L->pTete;
            while (i!=position)
            {
                pred=pred->suivant;
                i++;
            }
            succ=pred->suivant;
            succ->suivant=nouveuM;
            nouveuM->suivant=succ;
        }
      else printf("Erreur d'insertion!!\n");
       return nouveuM;

}
//********************InsererQueue********************
TListe InsererQueue (TListe *L,Tcomplexe val)
{
       TListe* elem=0;
       elem = (TListe*)malloc(sizeof(TListe));
       //elem=0;
       //Tmaillon p;//=L->pQueue;
       Tmaillon c;
       c=elem->pQueue;
       c->valeur=val;
       c->suivant=NULL;

       if(ListeVide(L))
         return *elem ;
         //printf("liste est vide\n");
        else
            while(c->suivant!=NULL) c=c->suivant;
        c->suivant=elem;
        return *L;
}


// *************suppression t�te********************************
void SupprTete(TListe* L)
{
    if (L->pTete!=NULL)
    {
        Tmaillon P=L->pTete;
        L->pTete=P->suivant;
        free(P);


    }

}

//********************* calculer le module********************************

double Module (Tcomplexe Z)
{
    double M;
    M=(Z.Reel)*(Z.Reel)+(Z.Im)*(Z.Im) ;
    M=sqrt(M);
  return M;
}
//********************** calculer la somme*********************************
Tcomplexe Somme (Tcomplexe Z1, Tcomplexe Z2 )
{
     Tcomplexe S;
     S.Reel= Z1.Reel + Z2.Reel;
     S.Im = Z1.Im + Z2.Im;
   return S;
}

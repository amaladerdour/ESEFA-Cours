#include <stdio.h>
#include <stdlib.h>
#include<conio.h>
#include"fonction.h"

int main()
{
    //d�claration des variables***
    int choix;
    TListe *L = malloc(sizeof(TListe));
    L=CreerListe();


    printf("\n***************GESTION DES NOMBRES COMPLEXES***************\n");
    printf("Effectuez un choix:\n");
    printf("1- Saisir un nombre complexe en tete\n");
    printf("2- Afficher le nombre complexe\n");
    printf("3- Nombre d'occurences\n");
    printf("4- Tester si le nombre est bien saisi\n");
    printf("5- Ajouter un nombre complexe au milieu\n");
    printf("6- Saisir un nombre complexe en fin\n");
    printf("7- Supprimer l'element du debut\n");
     do{
    printf("Tapez 0 pour quitter le programme\n");
    printf("\nSaisissez un choix:\t");
    scanf("%d",&choix);
      switch(choix)
      {
        case 1: {
                    Tcomplexe Val;
                    Tmaillon m;
                    printf("Saisissez la partie reelle du nombre complexe : ");
                    scanf("%f",&(Val.Reel));
                    printf("Saisissez la partie Imaginaire du nombre complexe : ");
                    scanf("%f",&(Val.Im));
                    if(InsererTete(L,Val));
                    else printf("probleme d'insertion");

                    //afficher_liste(L);

                };break;
        case 2:{
                        afficher_liste(L);

                };break;
        case 3:{
                    printf("La liste contient %d element(s)\n",LongListe(L));

               };break;
        case 4:{
                if (ListeVide(L))
                    printf("\nErreur, aucun nombre a afficher\n");
                else
                    printf("\n Le nombre a ete bien saisi \n");
               };break;
        case 5:{
                    Tcomplexe Val;
                    Tmaillon m;
                    printf("Saisissez la partie reelle du nombre complexe : ");
                    scanf("%f",&(Val.Reel));
                    printf("Saisissez la partie Imaginaire du nombre complexe : ");
                    scanf("%f",&(Val.Im));
                    InsererMaillon(L,Val);
                    afficher_liste(L);

                };break;
        case 6:{
                    Tcomplexe Val;
                    Tmaillon m;
                    printf("Saisissez la partie reelle du nombre complexe : ");
                    scanf("%f",&(Val.Reel));
                    printf("Saisissez la partie Imaginaire du nombre complexe : ");
                    scanf("%f",&(Val.Im));
                    InsererQueue(L,Val);
                    /*if()
                    else printf("probleme d'insertion");*/

                };break;
        case 7:{
                    //Tmaillon pL;
                    SupprTete(L);


                };break;

      }
    printf("\n");

       }while(choix!=0);
    free(L);
    return 0;
}

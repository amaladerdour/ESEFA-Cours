#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Mes_Fonctions.h"


int main(void)
{

    printf("********************GESTION D'UNE FILE D'ATTENTE D'UNE CAISSE D'UN SUPERMARCHE****************\n");
    TClient* client =malloc(sizeof(TClient));
    int choix;
    char nom[10];
    TFile *file =malloc(sizeof(TFile));
    file = Creer_file();//cree une file

    printf("Nom du caissier'e':\n");
    scanf("%s", &nom);
    //system("cls");
    printf("Bienvenue '%s' tu peux maintenant recevoir tes clients, le premier client arriv%c sur place est le premier servi!\n" , nom, 130);
    printf("\n------Effectuez un choix:------\n");

    printf("\t1- Tapez 1 pour recevoir le's' client's' !! \n");
    printf("\t2- Tapez 2 au cas ou le client a pay%c ou a quitt%c [ REMARQUE!!: Premier client arriv%c est le premier servi, il sera donc supprim%c de votre file d'attente!! ] \n",130,130,130,130);
    printf("\t3- le nombre des clients dans la file d'attente \n");
    printf("\t4- Supprimer tout les clients (NB: en cas de panne, vous pouvez annuler tout les clients!!) \n");
    printf("\t5- Afficher l'ensemble de la file d'attente de votre caisse \n");
    printf("\t6- Afficher le premier client arriv%c \n", 130 );
    printf("\t7- Afficher le dernier client arriv%c \n", 130);

    printf("\t!!ATTENTION!!: Si vous souhaitez quitter, TAPEZ 0\n");
    do{
    printf("Saisissez votre choix:\t");
    scanf("%d",&choix);
    switch(choix)
    {
        case 1:{// ajouter un client
                 printf("\tNom du client:   \t");
                 scanf("%s",client->nom);
                 printf("\tPr%cnom du client:\t",130);
                 scanf("%s",client->prenom);
                 printf("\tmontant a payer :\t");
                 scanf("%f",&client->montant_a_payer);
                 push_queue(file,*client);
               };break;
        case 2:{//Supprimer le premier element
                *client = queue_first(file);
                printf("\n\tle premier client est: %s %s - montant_a_payer: %.2fDH\n",client->nom ,client->prenom,client->montant_a_payer);
                pop_queue(file);
                printf("\tBRAVO!! Le premier client a et%c bien servi. \n",130);
               };break;
        case 3:{// l'affichage de la longueur de la file
                 printf("\tVotre file d'attent contient %d client's'.\n",queue_length(file));
               };break;
        case 4:{// Supprimer tous les elements de la file
                 clear_queue(file);
               };break;
        case 5:{// l'affichage de la file
                 printf(" - l'ensemble des clients en attente dans votre caisse est: \n");
                 print_queue(file);
               };break;
        case 6:{// l'affichage du premier element de la file
               *client = queue_first(file);
                printf("\nle prochain client est: [%s %s - montant_a_payer: %.2fDH]\n",client->nom ,client->prenom,client->montant_a_payer);
               };break;
        case 7:{// l'affichage de la queue la file
                *client = queue_last(file);
                printf("\nle dernier client est: [%s %s - montant_a_payer: %.2fDH]\n",client->nom ,client->prenom,client->montant_a_payer);
               };break;
     }
     printf("\n");
     }while(choix !=0);
    return 0;
}

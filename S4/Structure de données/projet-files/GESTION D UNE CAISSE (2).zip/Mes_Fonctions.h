#ifndef __MES_FONCTIONS__H__
#define __MES_FONCTIONS__H__

	/* D�finition du type Bool�en */
	typedef enum
	{
		false,
		true
	}Bool;

	/* structure de maillon */
	typedef struct client
    {
         char nom[25];
         char prenom[25];
         float montant_a_payer;
    }TClient;

	/* structure de maillon */
	typedef struct maillon
    {
         TClient value;
         struct maillon *next;
    }Tmaillon;


	/* structure de la File */
	typedef struct File
    {
        Tmaillon *first;
        Tmaillon *last;
        int nb_elements;
     }TFile;


	/* Prototypes */
	TFile *Creer_file(void);
	Bool is_empty_queue(TFile *file);
	int queue_length(TFile *file);
	TClient queue_first(TFile *file);
	TClient queue_last(TFile *file);
	void print_queue(TFile *file);
	void push_queue(TFile *file,TClient x);
	void pop_queue(TFile *file);
	void clear_queue(TFile *file);


#endif


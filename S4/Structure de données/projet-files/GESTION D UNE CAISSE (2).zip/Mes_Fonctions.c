#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Mes_fonctions.h"


// *********************La creation d'une file**************************
TFile *Creer_file(void)
{
    TFile *pL;
    pL= malloc(sizeof(TFile));
    pL->first = NULL;
    pL->last = NULL;
    pL->nb_elements = 0;
  return pL;
}

//************************************************************************

/**
* V�rifie qu'une File est vide
* @return true si elle ne contient pas d'�lements, false sinon
*/
Bool is_empty_queue(TFile *file)
{
	if(file->first == NULL && file->last == NULL)
		return true;

	return false;
}

/*------------------------------------------------------------------------*/

/**
* Retourne la longueur d'une File
* @return Le nombre d'�lements de la File
*/
int queue_length(TFile *file)
{
	return file->nb_elements;
}

/*------------------------------------------------------------------------*/

/**
* Retourne la t�te de la File
* @return La valeur en d�but de File
*/
TClient queue_first(TFile *file)
{
	if(is_empty_queue(file))
		exit(1);

	return file->first->value;
}

/*------------------------------------------------------------------------*/

/**
* Retourne la queue de la File
* @return La valeur en fin de File
*/
TClient queue_last(TFile *file)
{
	if(is_empty_queue(file))
		exit(1);

	return file->last->value;
}

/*------------------------------------------------------------------------*/

/**
* Affiche une File
*/
void print_queue(TFile *file)
{
	if(is_empty_queue(file))
	{
		printf("\tRien a afficher, la File est vide.\n");
		return;
	}

	Tmaillon *temp = file->first;

	while(temp != NULL)
	{
		printf("\t[%s %s - Montant a payer :%.2fDHs HT]\n",temp->value.nom,temp->value.prenom,temp->value.montant_a_payer);
		temp = temp->next;
	}
	printf("\n");
}

/*------------------------------------------------------------------------*/

/**
* Ins�re un client dans une File
* @param x Le client � ajouter
*/
void push_queue(TFile *file,TClient x)
{
	Tmaillon *element;
    element = malloc(sizeof(*element));

	if(element == NULL)
	{
		fprintf(stderr, "\tErreur : probleme allocation dynamique.\n");
		exit(EXIT_FAILURE);
	}

	element->value = x;
	element->next = NULL;

	if(is_empty_queue(file))
	{
		file->first = element;
		file->last = element;
	}
	else
	{
		file->last->next = element;
		file->last = element;
	}
	file->nb_elements++;
}

/*------------------------------------------------------------------------*/

/**
* Retire un �l�ment de la File
*/
void pop_queue(TFile *file)
{
	if(is_empty_queue(file))
	{
		printf("\tRien a retirer, la File est deja vide.\n");
		return;
	}

	Tmaillon *temp = file->first;

	if(file->first == file->last)
	{
		file->first = NULL;
		file->last = NULL;
	}
	else
		file->first = file->first->next;

	free(temp);
	file->nb_elements--;
}

/*------------------------------------------------------------------------*/

/**
* Nettoie la File de tous ses �l�ments
*/
void clear_queue(TFile *file)
{
	if(is_empty_queue(file))
	{
		printf("\tRien a nettoyer, la File est deja vide.\n");
		return;
	}

	while(!is_empty_queue(file))
		pop_queue(file);
}
